<?php
require 'connection.php';

if (isset($_POST['nama'], $_POST['noLoker'], $_POST['tanggal'], $_POST['idLoker'], $_POST['metodePembayaran'], $_POST['status'])) {
    $nama = $_POST['nama'];
    $noLoker = $_POST['noLoker'];
    $tanggal = $_POST['tanggal'];
    $idLoker = $_POST['idLoker'];
    $metodePembayaran = $_POST['metodePembayaran'];
    $status = $_POST['status'];
    //
    $sql = "INSERT INTO loker (nama, noLoker, tanggal, idLoker, metodePembayaran, status) VALUES ('$nama', '$noLoker', '$tanggal', '$idLoker', '$metodePembayaran', '$status')";
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Data not complete";
}

$conn->close();
?>