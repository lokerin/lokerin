<?php
require_once('connection.php');
parse_str(file_get_contents("php://input"), $_PUT);

$id = $_PUT['id'];
$nama = $_PUT['nama'];
$noLoker = $_PUT['noLoker'];
$tanggal = $_PUT['tanggal'];
$idLoker = $_PUT['idLoker'];
$metodePembayaran = $_PUT['metodePembayaran'];
$status = $_PUT['status'];

$query = "UPDATE loker SET 
                nama = '$nama',
                noLoker = '$noLoker',
                tanggal = '$tanggal',
                idLoker = '$idLoker',
                metodePembayaran = '$metodePembayaran',
                status = '$status'
                WHERE id = '$id'";
$sql = mysqli_query($conn, $query);

if ($sql) {
    echo json_encode(array('message' => 'Data berhasil diubah'));

} else {
    echo json_encode(array('message' => 'Gagal mengubah data'));
}

?>