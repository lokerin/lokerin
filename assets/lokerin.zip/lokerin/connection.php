<?php
    define('HOST', 'localhost');
    define('USER', 'root');
    define('PASS', '');
    define('DB', 'lokerin');

    $conn = mysqli_connect( HOST, USER, PASS, DB) or die ('unabel conect');

    header('Content-Type: application/json');
?>