<?php

require 'connection.php';

$sql = "SELECT * FROM loker";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $lokers = array();
    while ($row = $result->fetch_assoc()) {
        $lokers[] = $row;
    }

    $json = json_encode($lokers, JSON_PRETTY_PRINT);

    header('Content-Type: application/json');

    echo $json;
} else {
    echo json_encode(array());
}

$conn->close();

?>
